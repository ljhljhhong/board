package com.example.board.repository.impl;

public interface BoardCRepository {
    //Page<Board> findBoardList(PageRequestD param);
}
